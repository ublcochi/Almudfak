//slider
"use strict";
var Core;
(function (Core) {
  var Slider = (function () {
    function Slider() {
      // Durations
      this.durations = {
        auto: 7000,
        slide: 2400,
      };
      // DOM
      this.dom = {
        wrapper: null,
        container: null,
        project: null,
        current: null,
        next: null,
        arrow: null,
      };
      // Misc stuff
      this.length = 0;
      this.current = 0;
      this.next = 0;
      this.isAuto = true;
      this.working = false;
      this.dom.wrapper = $(".mask--slider");
      this.dom.project = this.dom.wrapper.find(".mask--slider--slide");
      this.dom.arrow = this.dom.wrapper.find(".arrow");
      this.length = this.dom.project.length;
      this.init();
      this.events();
      this.auto = setInterval(this.updateNext.bind(this), this.durations.auto);
    }
    /**
     * Set initial z-indexes & get current project
     */
    Slider.prototype.init = function () {
      this.dom.project.css("z-index", 10);
      this.dom.current = $(this.dom.project[this.current]);
      this.dom.next = $(this.dom.project[this.current + 1]);
      this.dom.current.css("z-index", 30);
      this.dom.next.css("z-index", 20);
    };
    Slider.prototype.clear = function () {
      this.dom.arrow.off("click");
      if (this.isAuto) clearInterval(this.auto);
    };
    /**
     * Initialize events
     */
    Slider.prototype.events = function () {
      var self = this;
      this.dom.arrow.on("click", function () {
        if (self.working) return;
        self.processBtn($(this));
      });
    };
    Slider.prototype.processBtn = function (btn) {
      if (this.isAuto) {
        this.isAuto = false;
        clearInterval(this.auto);
      }
      if (btn.hasClass("next")) this.updateNext();
      if (btn.hasClass("previous")) this.updatePrevious();
    };
    /**
     * Update next global index
     */
    Slider.prototype.updateNext = function () {
      this.next = (this.current + 1) % this.length;
      this.process();
    };
    /**
     * Update next global index
     */
    Slider.prototype.updatePrevious = function () {
      this.next--;
      if (this.next < 0) this.next = this.length - 1;
      this.process();
    };
    /**
     * Process, calculate and switch beetween slides
     */
    Slider.prototype.process = function () {
      var self = this;
      this.working = true;
      this.dom.next = $(this.dom.project[this.next]);
      this.dom.current.css("z-index", 30);
      self.dom.next.css("z-index", 20);
      // Hide current
      this.dom.current.addClass("hide");
      setTimeout(function () {
        self.dom.current.css("z-index", 10);
        self.dom.next.css("z-index", 30);
        self.dom.current.removeClass("hide");
        self.dom.current = self.dom.next;
        self.current = self.next;
        self.working = false;
      }, this.durations.slide);
    };
    return Slider;
  })();
  Core.Slider = Slider;
})(Core || (Core = {}));
document.addEventListener("DOMContentLoaded", function () {
  var imgLoad0 = imagesLoaded(
    ".mask--slider",
    { background: true },
    function () {
      console.log("mask--slider loaded");
    }
  );
  imgLoad0.on("done", function (instance) {
    new Core.Slider();
  });
});

//easescroll

//easescroll

//header
var cbpAnimatedHeader = (function () {
  var b = document.documentElement,
    g = document.querySelector(".header"),
    e = false,
    a = 30;

  function f() {
    window.addEventListener(
      "scroll",
      function (h) {
        if (!e) {
          e = true;
          setTimeout(d, 250);
        }
      },
      false
    );
  }

  function d() {
    var h = c();
    if (h >= a) {
      classie.add(g, "header-shrink");
    } else {
      classie.remove(g, "header-shrink");
    }
    e = false;
  }

  function c() {
    return window.pageYOffset || b.scrollTop;
  }
  f();
})();
//header

//splitter
window.addEventListener("load", function () {
  let splitWords = function (selector) {
    var elements = document.querySelectorAll(selector);

    elements.forEach(function (el) {
      el.dataset.splitText = el.textContent;
      el.innerHTML = el.textContent
        .split(/\s/)
        .map(function (word) {
          return word
            .split("-")
            .map(function (word) {
              return '<span class="word">' + word + "</span>";
            })
            .join('<span class="hyphen">-</span>');
        })
        .join('<span class="whitespace"> </span>');
    });
  };

  let splitLines = function (selector) {
    var elements = document.querySelectorAll(selector);

    splitWords(selector);

    elements.forEach(function (el) {
      var lines = getLines(el);

      var wrappedLines = "";
      lines.forEach(function (wordsArr) {
        wrappedLines += '<span class="line"><span class="words">';
        wordsArr.forEach(function (word) {
          wrappedLines += word.outerHTML;
        });
        wrappedLines += "</span></span>";
      });
      el.innerHTML = wrappedLines;
    });
  };

  let getLines = function (el) {
    var lines = [];
    var line;
    var words = el.querySelectorAll("span");
    var lastTop;
    for (var i = 0; i < words.length; i++) {
      var word = words[i];
      if (word.offsetTop != lastTop) {
        // Don't start with whitespace
        if (!word.classList.contains("whitespace")) {
          lastTop = word.offsetTop;

          line = [];
          lines.push(line);
        }
      }
      line.push(word);
    }
    return lines;
  };

  splitLines(".reveal-text");

  let revealText = document.querySelectorAll(".reveal-text");

  gsap.registerPlugin(ScrollTrigger);
  let revealLines = revealText.forEach((element) => {
    const lines = element.querySelectorAll(".words");

    let tl = gsap.timeline({
      scrollTrigger: {
        trigger: element,
        toggleActions: "restart none none reset",
      },
    });
    tl.set(element, { autoAlpha: 1 });
    tl.from(lines, 1, {
      yPercent: 100,
      ease: Power3.out,
      stagger: 0.25,
      delay: 0.2,
    });
  });
});
//splitter

// Easy Responsive Tabs Plugin
(function ($) {
  $.fn.extend({
    easyResponsiveTabs: function (options) {
      //Set the default values, use comma to separate the settings, example:
      var defaults = {
        type: "default", //default, vertical, accordion;
        width: "auto",
        fit: true,
        closed: false,
        activate: function () {},
      };
      //Variables
      var options = $.extend(defaults, options);
      var opt = options,
        jtype = opt.type,
        jfit = opt.fit,
        jwidth = opt.width,
        vtabs = "vertical",
        accord = "accordion";

      //Events
      $(this).bind("tabactivate", function (e, currentTab) {
        if (typeof options.activate === "function") {
          options.activate.call(currentTab, e);
        }
      });

      //Main function
      this.each(function () {
        var $respTabs = $(this);
        var $respTabsList = $respTabs.find("ul.resp-tabs-list");
        $respTabs.find("ul.resp-tabs-list li").addClass("resp-tab-item");
        $respTabs.css({
          display: "block",
          width: jwidth,
        });

        $respTabs
          .find(".resp-tabs-container > div")
          .addClass("resp-tab-content");
        jtab_options();
        //Properties Function
        function jtab_options() {
          if (jtype == vtabs) {
            $respTabs.addClass("resp-vtabs");
          }
          if (jfit == true) {
            $respTabs.css({ width: "100%", margin: "0px" });
          }
          if (jtype == accord) {
            $respTabs.addClass("resp-easy-accordion");
            $respTabs.find(".resp-tabs-list").css("display", "none");
          }
        }

        //Assigning the h2 markup to accordion title
        var $tabItemh2;
        $respTabs
          .find(".resp-tab-content")
          .before(
            "<h2 class='resp-accordion' role='tab'><span class='resp-arrow'></span></h2>"
          );

        var itemCount = 0;
        $respTabs.find(".resp-accordion").each(function () {
          $tabItemh2 = $(this);
          var innertext = $respTabs
            .find(".resp-tab-item:eq(" + itemCount + ")")
            .html();
          $respTabs
            .find(".resp-accordion:eq(" + itemCount + ")")
            .append(innertext);
          $tabItemh2.attr("aria-controls", "tab_item-" + itemCount);
          itemCount++;
        });

        //Assigning the 'aria-controls' to Tab items
        var count = 0,
          $tabContent;
        $respTabs.find(".resp-tab-item").each(function () {
          $tabItem = $(this);
          $tabItem.attr("aria-controls", "tab_item-" + count);
          $tabItem.attr("role", "tab");

          //First active tab, keep closed if option = 'closed' or option is 'accordion' and the element is in accordion mode
          if (
            options.closed !== true &&
            !(
              options.closed === "accordion" && !$respTabsList.is(":visible")
            ) &&
            !(options.closed === "tabs" && $respTabsList.is(":visible"))
          ) {
            $respTabs
              .find(".resp-tab-item")
              .first()
              .addClass("resp-tab-active");
            $respTabs
              .find(".resp-accordion")
              .first()
              .addClass("resp-tab-active");
            $respTabs
              .find(".resp-tab-content")
              .first()
              .addClass("resp-tab-content-active")
              .attr("style", "display:block");
          }

          //Assigning the 'aria-labelledby' attr to tab-content
          var tabcount = 0;
          $respTabs.find(".resp-tab-content").each(function () {
            $tabContent = $(this);
            $tabContent.attr("aria-labelledby", "tab_item-" + tabcount);
            tabcount++;
          });
          count++;
        });

        //Tab Click action function
        $respTabs.find("[role=tab]").each(function () {
          var $currentTab = $(this);
          $currentTab.click(function () {
            var $tabAria = $currentTab.attr("aria-controls");

            if (
              $currentTab.hasClass("resp-accordion") &&
              $currentTab.hasClass("resp-tab-active")
            ) {
              $respTabs
                .find(".resp-tab-content-active")
                .slideUp("", function () {
                  $(this).addClass("resp-accordion-closed");
                });
              $currentTab.removeClass("resp-tab-active");
              return false;
            }
            if (
              !$currentTab.hasClass("resp-tab-active") &&
              $currentTab.hasClass("resp-accordion")
            ) {
              $respTabs.find(".resp-tab-active").removeClass("resp-tab-active");
              $respTabs
                .find(".resp-tab-content-active")
                .slideUp()
                .removeClass("resp-tab-content-active resp-accordion-closed");
              $respTabs
                .find("[aria-controls=" + $tabAria + "]")
                .addClass("resp-tab-active");

              $respTabs
                .find(".resp-tab-content[aria-labelledby = " + $tabAria + "]")
                .slideDown()
                .addClass("resp-tab-content-active");
            } else {
              $respTabs.find(".resp-tab-active").removeClass("resp-tab-active");
              $respTabs
                .find(".resp-tab-content-active")
                .removeAttr("style")
                .removeClass("resp-tab-content-active")
                .removeClass("resp-accordion-closed");
              $respTabs
                .find("[aria-controls=" + $tabAria + "]")
                .addClass("resp-tab-active");
              $respTabs
                .find(".resp-tab-content[aria-labelledby = " + $tabAria + "]")
                .addClass("resp-tab-content-active")
                .attr("style", "display:block");
            }
            //Trigger tab activation event
            $currentTab.trigger("tabactivate", $currentTab);
          });
          //Window resize function
          $(window).resize(function () {
            $respTabs.find(".resp-accordion-closed").removeAttr("style");
          });
        });
      });
    },
  });
})(jQuery);

//Accodion

(function ($) {
  $.fn.smk_Accordion = function (options) {
    if (this.length > 1) {
      this.each(function () {
        $(this).smk_Accordion(options);
      });
      return this;
    }

    // Defaults
    var settings = $.extend(
      {
        animation: true,
        showIcon: true,
        closeAble: true,
        closeOther: true,
        slideSpeed: 150,
        activeIndex: false,
      },
      options
    );

    // Cache current instance
    // To avoid scope issues, use 'plugin' instead of 'this'
    // to reference this class from internal events and functions.
    var plugin = this;

    //"Constructor"
    var init = function () {
      plugin.createStructure();
      plugin.clickHead();
    };

    // Add .smk_accordion class
    this.createStructure = function () {
      //Add Class
      plugin.addClass("smk_accordion");
      if (settings.showIcon) {
        plugin.addClass("acc_with_icon");
      }

      //Create sections if they were not created already
      if (plugin.find(".accordion_in").length < 1) {
        plugin.children().addClass("accordion_in");
      }

      //Add classes to accordion head and content for each section
      plugin.find(".accordion_in").each(function (index, elem) {
        var childs = $(elem).children();
        $(childs[0]).addClass("acc_head");
        $(childs[1]).addClass("acc_content");
      });

      //Append icon
      if (settings.showIcon) {
        plugin.find(".acc_head").prepend('<div class="acc_icon_expand"></div>');
      }

      //Hide inactive
      plugin
        .find(".accordion_in .acc_content")
        .not(".acc_active .acc_content")
        .hide();

      //Active index
      if (settings.activeIndex === parseInt(settings.activeIndex)) {
        if (settings.activeIndex === 0) {
          plugin.find(".accordion_in").addClass("acc_active").show();
          plugin
            .find(".accordion_in .acc_content")
            .addClass("acc_active")
            .show();
        } else {
          plugin
            .find(".accordion_in")
            .eq(settings.activeIndex - 1)
            .addClass("acc_active")
            .show();
          plugin
            .find(".accordion_in .acc_content")
            .eq(settings.activeIndex - 1)
            .addClass("acc_active")
            .show();
        }
      }
    };

    // Action when the user click accordion head
    this.clickHead = function () {
      plugin.on("click", ".acc_head", function () {
        var s_parent = $(this).parent();

        if (s_parent.hasClass("acc_active") == false) {
          if (settings.closeOther) {
            plugin.find(".acc_content").slideUp(settings.slideSpeed);
            plugin.find(".accordion_in").removeClass("acc_active");
          }
        }

        if (s_parent.hasClass("acc_active")) {
          if (false !== settings.closeAble) {
            s_parent.children(".acc_content").slideUp(settings.slideSpeed);
            s_parent.removeClass("acc_active");
          }
        } else {
          $(this).next(".acc_content").slideDown(settings.slideSpeed);
          s_parent.addClass("acc_active");
        }
      });
    };

    //"Constructor" init
    init();
    return this;
  };
})(jQuery);

//modal
var ModalEffects = (function () {
  function init() {
    var overlay = document.querySelector(".md-overlay");

    [].slice
      .call(document.querySelectorAll(".md-trigger"))
      .forEach(function (el, i) {
        var modal = document.querySelector("#" + el.getAttribute("data-modal")),
          close = modal.querySelector(".md-close");

        function removeModal(hasPerspective) {
          classie.remove(modal, "md-show");

          if (hasPerspective) {
            classie.remove(document.documentElement, "md-perspective");
          }
        }

        function removeModalHandler() {
          removeModal(classie.has(el, "md-setperspective"));
        }

        el.addEventListener("click", function (ev) {
          classie.add(modal, "md-show");
          overlay.removeEventListener("click", removeModalHandler);
          overlay.addEventListener("click", removeModalHandler);
          if (classie.has(el, "md-setperspective")) {
            setTimeout(function () {
              classie.add(document.documentElement, "md-perspective");
            }, 25);
          }
        });

        close.addEventListener("click", function (ev) {
          ev.stopPropagation();
          removeModalHandler();
        });
      });
  }

  init();
})();

//parallax
$(window).scroll(function (e) {
  parallax();
});

function parallax() {
  var scroll = $(window).scrollTop();
  var screenHeight = $(window).height();

  $(".parallax").each(function () {
    var offset = $(this).offset().top;
    var distanceFromBottom = offset - scroll - screenHeight;

    if (offset > screenHeight && offset) {
      $(this).css(
        "background-position",
        "center " + distanceFromBottom * 0.5 + "px"
      );
    } else {
      $(this).css("background-position", "center " + -scroll * 0.5 + "px");
    }
  });
}
//parallax

//img-reveal
const options = {
  root: null,
  rootMargin: "0px",
  threshold: 0.9,
};

let revealCallback = (entries, self) => {
  entries.forEach((entry) => {
    let container = entry.target;
    let img = entry.target.querySelector("img");
    const easeInOut = "power3.out";
    const revealAnim = gsap.timeline({ ease: easeInOut });

    if (entry.isIntersecting) {
      revealAnim.set(container, {
        visibility: "visible",
      });
      revealAnim.fromTo(
        container,
        {
          clipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)",
          webkitClipPath: "polygon(0 0, 0 0, 0 100%, 0% 100%)",
        },
        {
          clipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
          webkitClipPath: "polygon(0 0, 100% 0, 100% 100%, 0 100%)",
          duration: 1,
          ease: easeInOut,
        }
      );
      revealAnim.from(img, 4, {
        scale: 1.4,
        ease: easeInOut,
        delay: -1,
      });
      self.unobserve(entry.target);
    }
  });
};

let revealObserver = new IntersectionObserver(revealCallback, options);

document.querySelectorAll(".reveal").forEach((reveal) => {
  revealObserver.observe(reveal);
});
//img-reveal
//initialize
$(document).ready(function () {
  //toggle
  $("#toggle").click(function () {
    $(this).toggleClass("active");
    $("#overlay").toggleClass("open");
  });
  //navigation-bg
  $(".navigation--link:nth-child(1)").on("mouseenter", function () {
    $(".navigation--link.active").removeClass("active");
    $(".navigation--img li.show").removeClass("show");
    $(".navigation--img li:nth-child(1)").addClass("show");
    $(".navigation--link:nth-child(1)").addClass("active");
  });
  $(".navigation--link:nth-child(2)").on("mouseenter", function () {
    $(".navigation--link.active").removeClass("active");
    $(".navigation--img li.show").removeClass("show");
    $(".navigation--img li:nth-child(2)").addClass("show");
    $(".navigation--link:nth-child(2)").addClass("active");
  });
  $(".navigation--link:nth-child(3)").on("mouseenter", function () {
    $(".navigation--link.active").removeClass("active");
    $(".navigation--img li.show").removeClass("show");
    $(".navigation--img li:nth-child(3)").addClass("show");
    $(".navigation--link:nth-child(3)").addClass("active");
  });
  $(".navigation--link:nth-child(4)").on("mouseenter", function () {
    $(".navigation--link.active").removeClass("active");
    $(".navigation--img li.show").removeClass("show");
    $(".navigation--img li:nth-child(4)").addClass("show");
    $(".navigation--link:nth-child(4)").addClass("active");
  });
  $(".navigation--link:nth-child(5)").on("mouseenter", function () {
    $(".navigation--link.active").removeClass("active");
    $(".navigation--img li.show").removeClass("show");
    $(".navigation--img li:nth-child(5)").addClass("show");
    $(".navigation--link:nth-child(5)").addClass("active");
  });
  $(".navigation--link:nth-child(1)").trigger("mouseenter");
  //img-drag
  $("img").on("dragstart", function (event) {
    event.preventDefault();
  });
  //scroll-up
  $(".up").click(function () {
    $("body,html").animate(
      {
        scrollTop: 0,
      },
      800
    );
    return false;
  });
  //wow
  new WOW().init();
  //tab
  $(".tab").easyResponsiveTabs({
    type: "default",
    width: "auto",
    fit: true,
    closed: "accordion",
    activate: function (event) {
      var $tab = $(this);
      var $info = $("#tabInfo");
      var $name = $("span", $info);
      $name.text($tab.text());
      $info.show();
    },
  });
  //accodion
  $(".accordion").smk_Accordion();
  //datepicker
  $(".datepicker").datepicker();
  $(".datepicker").attr("readonly", "readonly");
  //fancybox
  $(".zoom").fancybox({
    transitionEffect: "zoom-in-out",
  });
  //plus-minus
  $(".minus").click(function () {
    var $input = $(this).parent().find("input");
    var count = parseInt($input.val()) - 1;
    count = count < 1 ? 1 : count;
    $input.val(count);
    $input.change();
    return false;
  });
  $(".plus").click(function () {
    var $input = $(this).parent().find("input");
    $input.val(parseInt($input.val()) + 1);
    $input.change();
    return false;
  });
  //on-click-fadeout
  $(".cancel").click(function () {
    $("#cancel").fadeOut("slow");
  });
});
//initialize
